const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('password123', 10);

  const user = await prisma.user.upsert({
    where: { email: 'demo@example.com' },
    update: {},
    create: {
      username: 'demo_dev',
      email: 'demo@example.com',
      passwordHash,
      isAdmin: true
    }
  });

  const project = await prisma.project.upsert({
    where: { id: 'seed-project-1' },
    update: {},
    create: {
      id: 'seed-project-1',
      title: 'مثال: أداة تحويل العملات',
      description: 'سكربت بسيط لتحويل العملات باستخدام API مجاني.',
      language: 'JavaScript',
      code: "async function convert(amount, from, to) {\n  const res = await fetch(`https://api.exchangerate.host/convert?from=${from}&to=${to}`);\n  const data = await res.json();\n  return amount * data.info.rate;\n}",
      tags: ['api', 'finance'],
      featured: true,
      authorId: user.id
    }
  });

  await prisma.dailyStat.upsert({
    where: { projectId_date: { projectId: project.id, date: new Date(new Date().setUTCHours(0, 0, 0, 0)) } },
    update: {},
    create: { projectId: project.id, date: new Date(new Date().setUTCHours(0, 0, 0, 0)), views: 5 }
  });

  console.log('تم إنشاء بيانات تجريبية: demo@example.com / password123');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
