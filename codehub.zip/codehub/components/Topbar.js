'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import Link from 'next/link';

export default function Topbar({ onMenuClick }) {
  const router = useRouter();
  const [q, setQ] = useState('');

  function onSearch(e) {
    e.preventDefault();
    router.push(q ? `/?q=${encodeURIComponent(q)}` : '/');
  }

  return (
    <header className="topbar sticky top-0 z-40 px-6 py-3.5 flex items-center gap-4">
      <button className="lg:hidden icon-btn" onClick={onMenuClick}>☰</button>
      <form onSubmit={onSearch} className="search-box flex-1 max-w-2xl flex items-center gap-3 px-4 py-2.5">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6b6b85" strokeWidth="2.5"><circle cx="11" cy="11" r="7" /><path d="M21 21l-4-4" /></svg>
        <input
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="ابحث عن كود، مشروع، لغة..."
          className="bg-transparent outline-none flex-1 text-[13.5px] text-white placeholder:text-[#5c5c72]"
        />
      </form>
      <div className="flex items-center gap-2.5 mr-auto">
        <Link href="/publish" className="btn-primary hidden sm:inline-flex"><span>➕</span> نشر كود</Link>
      </div>
    </header>
  );
}
