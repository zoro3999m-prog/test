'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut } from 'next-auth/react';

const LIBRARY_LINKS = [
  { href: '/saved', label: 'المحفوظات', icon: '🔖' },
  { href: '/dashboard/assistant', label: 'مساعدك الشخصي', icon: '🤖', disabled: true }
];

const ACCOUNT_LINKS = [
  { href: '/dashboard', label: 'لوحة التحكم', icon: '📊' },
  { href: '/dashboard#my-projects', label: 'مشاريعي', icon: '📁' },
  { href: '/settings', label: 'الإعدادات', icon: '⚙️', disabled: true }
];

export default function Sidebar({ open, onClose }) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [libraryOpen, setLibraryOpen] = useState(true);
  const [accountOpen, setAccountOpen] = useState(true);

  const initial = session?.user?.name ? session.user.name[0].toUpperCase() : '?';

  return (
    <aside className={`sidebar w-[270px] flex-shrink-0 h-screen sticky top-0 flex flex-col ${open ? 'open' : ''}`}>
      <div className="px-5 pt-6 pb-4 flex items-center gap-3 relative z-10">
        <Link href="/" className="flex items-center gap-3">
          <div className="logo-mark"><span>{'</>'}</span></div>
          <div>
            <div className="logo-text">te<span>st</span></div>
            <div className="text-[10px] text-[#5c5c72] font-medium tracking-wider">مجتمع المبرمجين</div>
          </div>
        </Link>
      </div>

      <nav className="px-3 mt-2 flex-1 overflow-y-auto hide-scroll relative z-10 pb-6">
        <button className={`section-toggle ${libraryOpen ? 'open' : ''}`} onClick={() => setLibraryOpen((v) => !v)}>
          <span className="label">مكتبتك</span>
          <span className="divider" />
          <svg className="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
        </button>
        <div className={`section-content ${libraryOpen ? 'open' : ''}`}>
          {LIBRARY_LINKS.map((l) => (
            <Link key={l.href} href={l.disabled ? '#' : l.href} className={`nav-item ${pathname === l.href ? 'active' : ''}`} onClick={onClose}>
              <span className="ico">{l.icon}</span>
              <span>{l.label}</span>
            </Link>
          ))}
        </div>

        <button className={`section-toggle ${accountOpen ? 'open' : ''}`} onClick={() => setAccountOpen((v) => !v)}>
          <span className="label">حسابك</span>
          <span className="divider" />
          <svg className="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
        </button>
        <div className={`section-content ${accountOpen ? 'open' : ''}`}>
          {ACCOUNT_LINKS.map((l) => (
            <Link key={l.href} href={l.disabled ? '#' : l.href} className={`nav-item ${pathname === l.href ? 'active' : ''}`} onClick={onClose}>
              <span className="ico">{l.icon}</span>
              <span>{l.label}</span>
            </Link>
          ))}
        </div>
      </nav>

      <div className="p-3 border-t border-[rgba(255,255,255,.05)] relative z-10">
        {session ? (
          <button
            className="nav-item !py-2.5 w-full"
            style={{ background: 'rgba(139,92,246,.06)', borderColor: 'rgba(139,92,246,.15)' }}
            onClick={() => signOut({ callbackUrl: '/' })}
            title="تسجيل الخروج"
          >
            <div className="avatar relative">{initial}</div>
            <div className="flex-1 min-w-0 text-right">
              <div className="text-[13px] font-bold text-white truncate">{session.user.name}</div>
              <div className="text-[11px] text-[#6b6b85] truncate">تسجيل الخروج</div>
            </div>
          </button>
        ) : (
          <Link href="/login" className="btn-primary w-full justify-center">تسجيل الدخول</Link>
        )}
      </div>
    </aside>
  );
}
