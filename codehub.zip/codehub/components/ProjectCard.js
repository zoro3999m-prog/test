'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { formatNum, timeAgo, LANG_CLASS } from '../lib/format';

export default function ProjectCard({ project, initialSaved = false }) {
  const { data: session } = useSession();
  const router = useRouter();
  const [saved, setSaved] = useState(initialSaved);
  const [saving, setSaving] = useState(false);
  const [pop, setPop] = useState(false);

  async function toggleSave(e) {
    e.preventDefault();
    e.stopPropagation();
    if (!session) {
      router.push('/login');
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/projects/${project.id}/save`, { method: 'POST' });
      const data = await res.json();
      setSaved(data.saved);
      setPop(true);
      setTimeout(() => setPop(false), 450);
    } finally {
      setSaving(false);
    }
  }

  const langClass = LANG_CLASS[project.language] || 'lang-other';

  return (
    <Link href={`/project/${project.id}`} className="block">
      <article className={`card ${project.featured ? 'featured' : ''} h-full`}>
        <button
          className={`star-btn ${saved ? 'active' : ''} ${pop ? 'pop' : ''}`}
          onClick={toggleSave}
          disabled={saving}
          title={saved ? 'إزالة من المحفوظات' : 'حفظ في المحفوظات'}
        >
          <svg viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill={saved ? 'currentColor' : 'none'}>
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </button>
        <div className="flex items-start justify-between mb-3 pr-10">
          <span className={`lang-badge ${langClass}`}>{project.language}</span>
          {project.featured ? (
            <span className="text-[10.5px] font-bold px-2 py-1 rounded-md bg-[rgba(251,191,36,.15)] text-[#fbbf24] border border-[rgba(251,191,36,.3)]">⭐ مميز</span>
          ) : (
            <span className="text-[10.5px] text-[#5c5c72]">{timeAgo(project.createdAt)}</span>
          )}
        </div>
        <h3 className="text-[15.5px] font-bold text-white mb-1.5 hover:text-[#a855f7] transition">{project.title}</h3>
        <p className="text-[12.5px] text-[#8a8aa0] leading-relaxed mb-3 line-clamp-2">{project.description}</p>
        <div className="flex items-center gap-2 mb-3">
          <div className="avatar">{project.author?.[0]?.toUpperCase()}</div>
          <span className="text-[12.5px] text-[#b8b8c8] font-medium">{project.author}</span>
        </div>
        <div className="flex flex-wrap gap-1.5 mb-3.5">
          {(project.tags || []).map((t) => (
            <span key={t} className="tag">{t}</span>
          ))}
        </div>
        <div className="flex items-center justify-between pt-3.5 border-t border-[rgba(255,255,255,.05)]">
          <div className="flex items-center gap-3">
            <span className="stat">👁️ {formatNum(project.views)}</span>
            <span className="stat">❤️ {formatNum(project.likes)}</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="stat">⬇️ {formatNum(project.downloads)}</span>
            <span className="stat">📋 {formatNum(project.copies)}</span>
          </div>
        </div>
      </article>
    </Link>
  );
}
