'use client';

import { useEffect, useState, useCallback } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Shell from '../../components/Shell';
import ProjectCard from '../../components/ProjectCard';
import { formatNum, timeAgo } from '../../lib/format';

const RANGES = [
  { key: '24h', label: '24 ساعة' },
  { key: '1w', label: 'أسبوع' },
  { key: '1m', label: 'شهر' },
  { key: '4m', label: '4 شهور' },
  { key: '24m', label: '24 شهر' },
  { key: '1y', label: 'سنة' }
];

export default function DashboardPage() {
  const { status } = useSession();
  const router = useRouter();
  const [range, setRange] = useState('1w');
  const [data, setData] = useState(null);
  const [myProjects, setMyProjects] = useState(null);
  const [comments, setComments] = useState(null);

  const loadDashboard = useCallback((r) => {
    fetch(`/api/dashboard?range=${r}`).then((res) => res.json()).then(setData);
  }, []);

  useEffect(() => {
    if (status !== 'authenticated') return;
    loadDashboard(range);
  }, [status, range, loadDashboard]);

  useEffect(() => {
    if (status !== 'authenticated') return;
    fetch('/api/my/projects').then((r) => r.json()).then(setMyProjects);
    fetch('/api/my/comments').then((r) => r.json()).then(setComments);
  }, [status]);

  if (status === 'loading') return null;
  if (status === 'unauthenticated') {
    router.push('/login');
    return null;
  }

  async function moderate(id, action) {
    if (action === 'hide') {
      await fetch(`/api/comments/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ hidden: true }) });
      setComments((prev) => prev.map((c) => (c.id === id ? { ...c, hidden: true } : c)));
    } else if (action === 'delete') {
      if (!confirm('هل تريد حذف هذا التعليق نهائيًا؟')) return;
      await fetch(`/api/comments/${id}`, { method: 'DELETE' });
      setComments((prev) => prev.filter((c) => c.id !== id));
    } else if (action === 'report') {
      await fetch(`/api/comments/${id}`, { method: 'POST' });
      alert('تم إرسال البلاغ إلى الإدارة. شكرًا لك.');
    }
  }

  const chart = data?.chart;
  const maxVal = chart ? Math.max(...chart.bars, 0.01) : 1;

  return (
    <Shell>
      <section className="px-6 py-6">
        <div className="mb-6">
          <h1 className="text-[26px] font-extrabold text-white flex items-center gap-3"><span>📊</span> لوحة التحكم</h1>
          <p className="text-[13.5px] text-[#8a8aa0] mt-1.5">نظرة شاملة على أداء أكوادك وتفاعل المجتمع معها</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard label="عدد الأكواد المنشورة" icon="📁" value={data?.published ?? 0} />
          <StatCard label="الإعجابات" icon="❤️" value={formatNum(data?.likes ?? 0)} />
          <StatCard label="المشاهدات" icon="👁️" value={formatNum(data?.views ?? 0)} />
          <StatCard label="التحميلات" icon="⬇️" value={formatNum(data?.downloads ?? 0)} yellow />
        </div>

        <div className="mb-5 flex items-center gap-2 overflow-x-auto hide-scroll pb-1">
          <span className="text-[12px] text-[#5c5c72] font-semibold whitespace-nowrap">الفترة:</span>
          {RANGES.map((r) => (
            <button key={r.key} className={`pill ${range === r.key ? 'active' : ''}`} onClick={() => setRange(r.key)}>{r.label}</button>
          ))}
        </div>

        <div className="activity-card mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4 mb-2">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="text-[36px] font-extrabold text-white leading-none mono">{formatNum(chart?.total ?? 0)}</div>
                <span className="text-[11.5px] font-bold px-2.5 py-1 rounded-lg bg-[rgba(255,255,255,.06)] text-[#8a8aa0] border border-[rgba(255,255,255,.08)] mono">{chart?.trend ?? '— 0%'}</span>
              </div>
              <div className="text-[12.5px] text-[#8a8aa0]">آخر 7 أيام، {chart?.diffText ?? '0'} مقارنة بالأسبوع السابق</div>
            </div>
          </div>

          <div className="bar-track">
            {(chart?.bars ?? [0, 0, 0, 0, 0, 0, 0]).map((val, i) => {
              const isToday = i === 6;
              const isEmpty = val === 0;
              const heightPct = isEmpty ? 0 : Math.max(12, (val / maxVal) * 100);
              return (
                <div key={i} className="bar-col">
                  {isToday && !isEmpty && <span className="bar-tip">{formatNum(val)}</span>}
                  <div className={isEmpty ? 'bar empty' : isToday ? 'bar' : 'bar dim'} style={isEmpty ? {} : { height: `${heightPct}%` }} />
                  <div className={`bar-label ${isToday ? 'today' : ''}`}>{chart?.labels?.[i] ?? ''}</div>
                </div>
              );
            })}
          </div>

          <div className="chart-footer">
            <div>
              <div className="text-[16px] font-extrabold text-white mono">{formatNum(chart?.avg ?? 0)}</div>
              <div className="text-[11px] text-[#5c5c72] mt-1">متوسط مشاهدات اليوم النشط</div>
            </div>
            <div>
              <div className="text-[16px] font-extrabold text-white mono">{formatNum(chart?.longest ?? 0)}</div>
              <div className="text-[11px] text-[#5c5c72] mt-1">أعلى يوم مشاهدات</div>
            </div>
            <div>
              <div className="text-[16px] font-extrabold text-white mono">{chart?.activeDays ?? 0} of 7</div>
              <div className="text-[11px] text-[#5c5c72] mt-1">أيام النشاط</div>
            </div>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[17px] font-extrabold text-white flex items-center gap-2"><span>💬</span> التعليقات على أكوادي</h2>
            <span className="text-[12px] text-[#5c5c72]">{comments?.length ?? 0} تعليق</span>
          </div>

          {!comments ? (
            <p className="text-[13px] text-[#8a8aa0]">جارِ التحميل...</p>
          ) : comments.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[rgba(255,255,255,.08)] bg-[rgba(255,255,255,.01)] p-10 text-center">
              <div className="text-3xl mb-3 opacity-60">💬</div>
              <p className="text-[13px] text-[#8a8aa0]">لا توجد تعليقات على أكوادك حتى الآن.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {comments.map((c) => (
                <div key={c.id} className="comment-item" style={c.hidden ? { opacity: 0.4 } : {}}>
                  <div className="flex items-start gap-3">
                    <div className="avatar">{c.user?.[0]?.toUpperCase()}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[12.5px] font-bold text-white">{c.user}</span>
                        <span className="text-[10.5px] text-[#5c5c72]">• {timeAgo(c.createdAt)}</span>
                        <span className="text-[10.5px] text-[#5c5c72]">على {c.projectTitle}</span>
                      </div>
                      <p className="text-[12.5px] text-[#b8b8c8] leading-relaxed mb-2">{c.text}</p>
                      <div className="flex items-center gap-1 flex-wrap">
                        <button className="comment-action warn" onClick={() => moderate(c.id, 'hide')} disabled={c.hidden}>{c.hidden ? '✔ مخفي' : 'إخفاء'}</button>
                        <button className="comment-action danger" onClick={() => moderate(c.id, 'delete')}>حذف</button>
                        <button className="comment-action" onClick={() => moderate(c.id, 'report')}>إبلاغ للإدارة</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div id="my-projects" className="mb-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[17px] font-extrabold text-white flex items-center gap-2"><span>📁</span> أكوادي المنشورة</h2>
            <span className="text-[12px] text-[#5c5c72]">{myProjects?.length ?? 0} كود</span>
          </div>

          {!myProjects ? (
            <p className="text-[13px] text-[#8a8aa0]">جارِ التحميل...</p>
          ) : myProjects.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[rgba(139,92,246,.25)] bg-[rgba(139,92,246,.03)] p-14 text-center">
              <div className="w-20 h-20 mx-auto mb-5 rounded-2xl bg-gradient-to-br from-[rgba(139,92,246,.2)] to-transparent border border-[rgba(139,92,246,.3)] flex items-center justify-center text-3xl">📭</div>
              <h3 className="text-[18px] font-bold text-white mb-2">لم يتم نشر أي أكواد لك</h3>
              <p className="text-[13px] text-[#8a8aa0] max-w-md mx-auto mb-6 leading-relaxed">ابدأ بنشر أول كود لك على المنصة، وشارك إبداعك مع مجتمع المبرمجين.</p>
              <a href="/publish" className="btn-primary inline-flex"><span>➕</span> نشر كود</a>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {myProjects.map((p) => <ProjectCard key={p.id} project={p} />)}
            </div>
          )}
        </div>
      </section>
    </Shell>
  );
}

function StatCard({ label, icon, value, yellow }) {
  return (
    <div className={`stat-card ${yellow ? 'yellow' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <div className="text-[11.5px] text-[#8a8aa0] font-semibold">{label}</div>
        <div className="w-9 h-9 rounded-lg bg-[rgba(139,92,246,.12)] border border-[rgba(139,92,246,.25)] flex items-center justify-center text-[15px]">{icon}</div>
      </div>
      <div className="text-[28px] font-extrabold text-white leading-none">{value}</div>
    </div>
  );
}
