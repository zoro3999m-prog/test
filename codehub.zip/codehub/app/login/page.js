'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function LoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    const res = await signIn('credentials', { identifier, password, redirect: false });
    setLoading(false);
    if (res?.error) {
      setError('اسم المستخدم أو كلمة المرور غير صحيحة');
      return;
    }
    router.push('/');
    router.refresh();
  }

  return (
    <div className="min-h-screen main-bg flex items-center justify-center px-4">
      <form onSubmit={onSubmit} className="w-full max-w-sm card">
        <div className="flex items-center gap-3 mb-6 justify-center">
          <div className="logo-mark"><span>{'</>'}</span></div>
          <div className="logo-text">te<span>st</span></div>
        </div>
        <h1 className="text-[20px] font-extrabold text-white mb-1 text-center">تسجيل الدخول</h1>
        <p className="text-[12.5px] text-[#8a8aa0] mb-6 text-center">أهلاً بعودتك 👋</p>

        {error && <p className="text-[12.5px] text-[#f87171] bg-[rgba(248,113,113,.1)] border border-[rgba(248,113,113,.25)] rounded-lg px-3 py-2 mb-4">{error}</p>}

        <label className="form-label">اسم المستخدم أو البريد الإلكتروني</label>
        <input className="form-input mb-4" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />

        <label className="form-label">كلمة المرور</label>
        <input type="password" className="form-input mb-6" value={password} onChange={(e) => setPassword(e.target.value)} required />

        <button className="btn-primary w-full justify-center" disabled={loading}>{loading ? 'جارِ الدخول...' : 'دخول'}</button>

        <p className="text-[12.5px] text-[#8a8aa0] text-center mt-5">
          مفيش حساب؟ <Link href="/register" className="text-[#c4b5fd] font-bold">أنشئ حساب جديد</Link>
        </p>
      </form>
    </div>
  );
}
