'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Shell from '../components/Shell';
import ProjectCard from '../components/ProjectCard';
import { formatNum } from '../lib/format';

const TABS = [
  { key: 'trending', label: '🔥 الرائجة' },
  { key: 'newest', label: '🆕 الأحدث' },
  { key: 'views', label: '👁️ الأكثر مشاهدة' },
  { key: 'likes', label: '❤️ الأكثر إعجابًا' },
  { key: 'downloads', label: '⬇️ الأكثر تحميلًا' },
  { key: 'copies', label: '📋 الأكثر نسخًا' },
  { key: 'featured', label: '⭐ المشاريع المميزة', yellow: true }
];

function HomeInner() {
  const searchParams = useSearchParams();
  const q = searchParams.get('q') || '';
  const { data: session } = useSession();
  const [sort, setSort] = useState('trending');
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [savedIds, setSavedIds] = useState(new Set());

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (sort === 'featured') params.set('featured', '1');
    else params.set('sort', sort);
    if (q) params.set('q', q);

    fetch(`/api/projects?${params.toString()}`)
      .then((r) => r.json())
      .then((data) => setProjects(Array.isArray(data) ? data : []))
      .finally(() => setLoading(false));
  }, [sort, q]);

  const totalViews = projects.reduce((a, p) => a + p.views, 0);
  const totalLikes = projects.reduce((a, p) => a + p.likes, 0);

  return (
    <Shell>
      <section className="px-6 py-6">
        <div className="mb-7 flex items-start justify-between flex-wrap gap-4 anim-fade-up">
          <div>
            <h1 className="text-[26px] md:text-[30px] font-extrabold text-white leading-tight">
              مرحبًا {session ? <span className="glow-text">{session.user.name}</span> : <span className="glow-text">بيك</span>} 👋
            </h1>
            <p className="text-[13.5px] text-[#8a8aa0] mt-1.5">اكتشف أحدث الأكواد والمشاريع من مجتمع المبرمجين.</p>
          </div>
        </div>

        <div className="mb-5 flex items-center gap-2 overflow-x-auto hide-scroll pb-1 anim-fade-up" style={{ animationDelay: '.1s' }}>
          {TABS.map((t) => (
            <button
              key={t.key}
              className={`tab ${sort === t.key ? 'active' : ''} ${t.yellow ? 'yellow' : ''}`}
              onClick={() => setSort(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        {q && (
          <p className="text-[13px] text-[#8a8aa0] mb-4">نتائج البحث عن: <span className="text-white font-bold">{q}</span></p>
        )}

        {loading ? (
          <p className="text-[#5c5c72] text-sm">جارِ التحميل...</p>
        ) : projects.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-[rgba(139,92,246,.25)] bg-[rgba(139,92,246,.03)] p-14 text-center">
            <div className="text-3xl mb-3 opacity-70">📭</div>
            <h2 className="text-[18px] font-bold text-white mb-2">لا توجد أكواد بعد</h2>
            <p className="text-[13px] text-[#8a8aa0]">كن أول من ينشر كودًا على المنصة.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {projects.map((p) => (
              <ProjectCard key={p.id} project={p} initialSaved={savedIds.has(p.id)} />
            ))}
          </div>
        )}
      </section>
    </Shell>
  );
}

export default function HomePage() {
  return (
    <Suspense>
      <HomeInner />
    </Suspense>
  );
}
