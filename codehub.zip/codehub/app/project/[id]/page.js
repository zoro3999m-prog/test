'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Shell from '../../../components/Shell';
import { formatNum, timeAgo, LANG_CLASS } from '../../../lib/format';

export default function ProjectDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const { data: session } = useSession();
  const [project, setProject] = useState(null);
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState('');
  const [notFound, setNotFound] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    fetch(`/api/projects/${id}`)
      .then((r) => {
        if (!r.ok) throw new Error();
        return r.json();
      })
      .then(setProject)
      .catch(() => setNotFound(true));

    fetch(`/api/projects/${id}/comments`)
      .then((r) => r.json())
      .then(setComments);
  }, [id]);

  async function toggleLike() {
    if (!session) return router.push('/login');
    const res = await fetch(`/api/projects/${id}/like`, { method: 'POST' });
    const data = await res.json();
    setProject((p) => ({ ...p, likedByMe: data.liked, likes: data.total }));
  }

  async function toggleSave() {
    if (!session) return router.push('/login');
    const res = await fetch(`/api/projects/${id}/save`, { method: 'POST' });
    const data = await res.json();
    setProject((p) => ({ ...p, savedByMe: data.saved }));
  }

  async function onCopy() {
    await navigator.clipboard.writeText(project.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    fetch('/api/track', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ projectId: id, type: 'copy' }) });
    setProject((p) => ({ ...p, copies: p.copies + 1 }));
  }

  function onDownload() {
    const ext = { JavaScript: 'js', Python: 'py', PHP: 'php', 'C++': 'cpp', Go: 'go', Rust: 'rs' }[project.language] || 'txt';
    const blob = new Blob([project.code], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.title}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
    fetch('/api/track', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ projectId: id, type: 'download' }) });
    setProject((p) => ({ ...p, downloads: p.downloads + 1 }));
  }

  async function onSubmitComment(e) {
    e.preventDefault();
    if (!session) return router.push('/login');
    if (!commentText.trim()) return;
    const res = await fetch(`/api/projects/${id}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: commentText })
    });
    if (res.ok) {
      const c = await res.json();
      setComments((prev) => [c, ...prev]);
      setCommentText('');
    }
  }

  async function onDeleteProject() {
    if (!confirm('هل تريد حذف هذا الكود نهائيًا؟')) return;
    const res = await fetch(`/api/projects/${id}`, { method: 'DELETE' });
    if (res.ok) router.push('/dashboard');
  }

  if (notFound) {
    return (
      <Shell>
        <div className="px-6 py-16 text-center">
          <div className="text-4xl mb-4">🚫</div>
          <h1 className="text-white text-xl font-bold">الكود غير موجود</h1>
        </div>
      </Shell>
    );
  }

  if (!project) {
    return (
      <Shell>
        <div className="px-6 py-16 text-center text-[#5c5c72]">جارِ التحميل...</div>
      </Shell>
    );
  }

  const langClass = LANG_CLASS[project.language] || 'lang-other';
  const isOwner = session?.user?.id === project.authorId;

  return (
    <Shell>
      <section className="px-6 py-6 max-w-4xl">
        <div className="card mb-6">
          <div className="flex items-start justify-between mb-3 flex-wrap gap-2">
            <span className={`lang-badge ${langClass}`}>{project.language}</span>
            {isOwner && (
              <button onClick={onDeleteProject} className="comment-action danger">🗑 حذف الكود</button>
            )}
          </div>
          <h1 className="text-[24px] font-extrabold text-white mb-2">{project.title}</h1>
          <p className="text-[13.5px] text-[#8a8aa0] leading-relaxed mb-4">{project.description}</p>

          <div className="flex items-center gap-2 mb-4">
            <div className="avatar">{project.author?.[0]?.toUpperCase()}</div>
            <span className="text-[13px] text-[#b8b8c8] font-medium">{project.author}</span>
            <span className="text-[11px] text-[#4a4a60]">• {timeAgo(project.createdAt)}</span>
          </div>

          <div className="flex flex-wrap gap-1.5 mb-4">
            {(project.tags || []).map((t) => <span key={t} className="tag">{t}</span>)}
          </div>

          <div className="flex items-center gap-3 flex-wrap pt-4 border-t border-[rgba(255,255,255,.05)]">
            <button onClick={toggleLike} className={`pill ${project.likedByMe ? 'active' : ''}`}>❤️ {formatNum(project.likes)}</button>
            <button onClick={toggleSave} className={`pill ${project.savedByMe ? 'active' : ''}`}>⭐ {project.savedByMe ? 'محفوظ' : 'حفظ'}</button>
            <button onClick={onDownload} className="btn-ghost">⬇️ تحميل ({formatNum(project.downloads)})</button>
            <button onClick={onCopy} className="btn-ghost">{copied ? '✔ تم النسخ' : `📋 نسخ الكود (${formatNum(project.copies)})`}</button>
            <span className="stat mr-auto">👁️ {formatNum(project.views)} مشاهدة</span>
          </div>
        </div>

        <div className="code-box mb-8">{project.code}</div>

        <div>
          <h2 className="text-[17px] font-extrabold text-white mb-4 flex items-center gap-2">💬 التعليقات ({comments.length})</h2>

          <form onSubmit={onSubmitComment} className="flex gap-2 mb-5">
            <input
              className="form-input"
              placeholder={session ? 'اكتب تعليقك...' : 'سجل الدخول عشان تعلق'}
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
            />
            <button className="btn-primary flex-shrink-0">إرسال</button>
          </form>

          {comments.length === 0 ? (
            <p className="text-[13px] text-[#8a8aa0]">لا توجد تعليقات بعد.</p>
          ) : (
            <div className="space-y-3">
              {comments.map((c) => (
                <div key={c.id} className="comment-item">
                  <div className="flex items-start gap-3">
                    <div className="avatar">{c.user?.[0]?.toUpperCase()}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[12.5px] font-bold text-white">{c.user}</span>
                        <span className="text-[10.5px] text-[#5c5c72]">• {timeAgo(c.createdAt)}</span>
                      </div>
                      <p className="text-[12.5px] text-[#b8b8c8] leading-relaxed">{c.text}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </Shell>
  );
}
