'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Shell from '../../components/Shell';

const LANGUAGES = ['JavaScript', 'Python', 'PHP', 'C++', 'Go', 'Rust', 'أخرى'];

export default function PublishPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [language, setLanguage] = useState('JavaScript');
  const [tags, setTags] = useState('');
  const [code, setCode] = useState('');
  const [agree, setAgree] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  if (status === 'loading') return null;
  if (status === 'unauthenticated') {
    router.push('/login');
    return null;
  }

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    if (!agree) {
      setError('لازم توافق على شروط النشر أولاً');
      return;
    }
    setLoading(true);
    const res = await fetch('/api/projects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title,
        description,
        language,
        code,
        tags: tags.split(',').map((t) => t.trim()).filter(Boolean)
      })
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error || 'حدث خطأ أثناء النشر');
      return;
    }
    router.push(`/project/${data.id}`);
  }

  return (
    <Shell>
      <section className="px-6 py-6 max-w-3xl">
        <h1 className="text-[26px] font-extrabold text-white mb-1">➕ نشر كود جديد</h1>
        <p className="text-[13.5px] text-[#8a8aa0] mb-6">شارك كودك مع مجتمع المبرمجين</p>

        {error && <p className="text-[12.5px] text-[#f87171] bg-[rgba(248,113,113,.1)] border border-[rgba(248,113,113,.25)] rounded-lg px-3 py-2 mb-4">{error}</p>}

        <form onSubmit={onSubmit} className="card space-y-4">
          <div>
            <label className="form-label">عنوان الكود</label>
            <input className="form-input" value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={120} />
          </div>

          <div>
            <label className="form-label">وصف مختصر</label>
            <textarea className="form-input" rows={3} value={description} onChange={(e) => setDescription(e.target.value)} required maxLength={500} />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="form-label">لغة البرمجة</label>
              <select className="form-input" value={language} onChange={(e) => setLanguage(e.target.value)}>
                {LANGUAGES.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="form-label">الوسوم (افصل بينها بفاصلة)</label>
              <input className="form-input" placeholder="react, api, cli" value={tags} onChange={(e) => setTags(e.target.value)} />
            </div>
          </div>

          <div>
            <label className="form-label">الكود</label>
            <textarea className="form-input mono" rows={12} style={{ direction: 'ltr', textAlign: 'left' }} value={code} onChange={(e) => setCode(e.target.value)} required />
          </div>

          <label className="flex items-start gap-2.5 text-[12.5px] text-[#8a8aa0]">
            <input type="checkbox" className="mt-1" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            <span>
              أقر بأن هذا الكود من تأليفي أو لدي حق نشره، وأنه لا يحتوي على برمجيات ضارة أو أدوات اختراق أو أي محتوى مخالف
              للقانون أو ينتهك خصوصية الآخرين، وأتحمل المسؤولية الكاملة عن محتواه.
            </span>
          </label>

          <button className="btn-primary" disabled={loading}>{loading ? 'جارِ النشر...' : 'نشر الكود'}</button>
        </form>
      </section>
    </Shell>
  );
}
