import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

  const comments = await prisma.comment.findMany({
    where: { project: { authorId: session.user.id } },
    orderBy: { createdAt: 'desc' },
    include: {
      user: { select: { username: true } },
      project: { select: { title: true } }
    }
  });

  return NextResponse.json(
    comments.map((c) => ({
      id: c.id,
      text: c.text,
      hidden: c.hidden,
      createdAt: c.createdAt,
      user: c.user.username,
      projectTitle: c.project.title
    }))
  );
}
