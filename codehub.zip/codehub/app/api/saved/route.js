import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../lib/auth';
import { prisma } from '../../../lib/prisma';

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

  const saves = await prisma.save.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: 'desc' },
    include: {
      project: {
        include: {
          author: { select: { username: true } },
          _count: { select: { likes: true, saves: true, comments: true } },
          dailyStats: true
        }
      }
    }
  });

  const shaped = saves
    .filter((s) => !s.project.hidden)
    .map((s) => {
      const p = s.project;
      return {
        id: p.id,
        title: p.title,
        description: p.description,
        language: p.language,
        tags: p.tags,
        featured: p.featured,
        createdAt: p.createdAt,
        author: p.author.username,
        views: p.dailyStats.reduce((a, d) => a + d.views, 0),
        downloads: p.dailyStats.reduce((a, d) => a + d.downloads, 0),
        copies: p.dailyStats.reduce((a, d) => a + d.copies, 0),
        likes: p._count.likes
      };
    });

  return NextResponse.json(shaped);
}
