import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';

async function canModerate(session, comment) {
  if (!session) return false;
  if (comment.userId === session.user.id) return true; // صاحب التعليق نفسه
  const project = await prisma.project.findUnique({ where: { id: comment.projectId } });
  if (project?.authorId === session.user.id) return true; // صاحب الكود
  const me = await prisma.user.findUnique({ where: { id: session.user.id } });
  return !!me?.isAdmin;
}

export async function PATCH(req, { params }) {
  // إخفاء التعليق (لصاحب الكود فقط)
  const session = await getServerSession(authOptions);
  const comment = await prisma.comment.findUnique({ where: { id: params.id } });
  if (!comment) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });

  const ok = await canModerate(session, comment);
  if (!ok) return NextResponse.json({ error: 'مش مسموح' }, { status: 403 });

  const body = await req.json();
  const updated = await prisma.comment.update({
    where: { id: params.id },
    data: { hidden: !!body.hidden }
  });
  return NextResponse.json({ id: updated.id, hidden: updated.hidden });
}

export async function DELETE(req, { params }) {
  const session = await getServerSession(authOptions);
  const comment = await prisma.comment.findUnique({ where: { id: params.id } });
  if (!comment) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });

  const ok = await canModerate(session, comment);
  if (!ok) return NextResponse.json({ error: 'مش مسموح' }, { status: 403 });

  await prisma.comment.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}

export async function POST(req, { params }) {
  // إبلاغ عن تعليق
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'لازم تسجل الدخول عشان تبلغ' }, { status: 401 });

  const comment = await prisma.comment.findUnique({ where: { id: params.id } });
  if (!comment) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });

  await prisma.commentModeration.create({
    data: { commentId: params.id, userId: session.user.id, action: 'report' }
  });
  return NextResponse.json({ ok: true });
}
