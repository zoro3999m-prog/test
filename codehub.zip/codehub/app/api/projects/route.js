import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../lib/auth';
import { prisma } from '../../../lib/prisma';
import { dayKey } from '../../../lib/format';

// قائمة قصيرة من الكلمات المحظورة كخط دفاع أول فقط — المراجعة الحقيقية للمحتوى
// (بلاغات المستخدمين + مراجعة الأدمن عبر لوحة /dashboard/admin) هي خط الدفاع الأساسي
const BLOCKED_PATTERNS = [/password\s*stealer/i, /keylogger/i, /ddos\s*(tool|script)/i, /credit\s*card\s*(dump|generator)/i];

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const sort = searchParams.get('sort') || 'trending';
  const language = searchParams.get('language');
  const featuredOnly = searchParams.get('featured') === '1';
  const q = searchParams.get('q');

  const where = { hidden: false };
  if (language) where.language = language;
  if (featuredOnly) where.featured = true;
  if (q) {
    where.OR = [
      { title: { contains: q, mode: 'insensitive' } },
      { description: { contains: q, mode: 'insensitive' } },
      { tags: { has: q } }
    ];
  }

  let orderBy = { createdAt: 'desc' };
  const projects = await prisma.project.findMany({
    where,
    orderBy,
    take: 60,
    include: {
      author: { select: { username: true } },
      _count: { select: { likes: true, saves: true, comments: true } },
      dailyStats: true
    }
  });

  const shaped = projects
    .map((p) => {
      const views = p.dailyStats.reduce((a, d) => a + d.views, 0);
      const downloads = p.dailyStats.reduce((a, d) => a + d.downloads, 0);
      const copies = p.dailyStats.reduce((a, d) => a + d.copies, 0);
      return {
        id: p.id,
        title: p.title,
        description: p.description,
        language: p.language,
        tags: p.tags,
        featured: p.featured,
        createdAt: p.createdAt,
        author: p.author.username,
        views,
        downloads,
        copies,
        likes: p._count.likes,
        saves: p._count.saves,
        comments: p._count.comments
      };
    })
    .sort((a, b) => {
      if (sort === 'newest') return new Date(b.createdAt) - new Date(a.createdAt);
      if (sort === 'views') return b.views - a.views;
      if (sort === 'likes') return b.likes - a.likes;
      if (sort === 'downloads') return b.downloads - a.downloads;
      if (sort === 'copies') return b.copies - a.copies;
      // trending: مزيج بسيط من التفاعل الحديث
      return b.likes + b.views / 10 - (a.likes + a.views / 10);
    });

  return NextResponse.json(shaped);
}

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) {
    return NextResponse.json({ error: 'لازم تسجل الدخول عشان تنشر كود' }, { status: 401 });
  }

  const body = await req.json();
  const title = (body.title || '').trim();
  const description = (body.description || '').trim();
  const language = (body.language || '').trim();
  const code = body.code || '';
  const tags = Array.isArray(body.tags) ? body.tags.filter(Boolean).slice(0, 8) : [];

  if (!title || !description || !language || !code) {
    return NextResponse.json({ error: 'من فضلك أكمل كل الحقول الأساسية' }, { status: 400 });
  }
  if (code.length > 200000) {
    return NextResponse.json({ error: 'حجم الكود كبير جدًا' }, { status: 400 });
  }

  const blob = `${title} ${description} ${code}`;
  if (BLOCKED_PATTERNS.some((re) => re.test(blob))) {
    return NextResponse.json(
      { error: 'هذا الكود يخالف شروط الاستخدام (أدوات ضارة/غير قانونية) ولا يمكن نشره' },
      { status: 422 }
    );
  }

  const project = await prisma.project.create({
    data: {
      title,
      description,
      language,
      code,
      tags,
      authorId: session.user.id
    }
  });

  // نجهز صف إحصائيات اليوم من أول لحظة نشر عشان لوحة التحكم تلاقي بيانات حقيقية فورًا
  await prisma.dailyStat.create({
    data: { projectId: project.id, date: dayKey() }
  });

  return NextResponse.json({ id: project.id });
}
