import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../lib/auth';
import { prisma } from '../../../../lib/prisma';
import { dayKey } from '../../../../lib/format';

export async function GET(req, { params }) {
  const project = await prisma.project.findUnique({
    where: { id: params.id },
    include: {
      author: { select: { id: true, username: true } },
      _count: { select: { likes: true, saves: true, comments: true } },
      dailyStats: true
    }
  });
  if (!project || project.hidden) {
    return NextResponse.json({ error: 'الكود غير موجود' }, { status: 404 });
  }

  // كل مشاهدة فعلية للصفحة = +1 مشاهدة حقيقية على DailyStat لهذا اليوم
  await prisma.dailyStat.upsert({
    where: { projectId_date: { projectId: project.id, date: dayKey() } },
    update: { views: { increment: 1 } },
    create: { projectId: project.id, date: dayKey(), views: 1 }
  });

  const views = project.dailyStats.reduce((a, d) => a + d.views, 0) + 1;
  const downloads = project.dailyStats.reduce((a, d) => a + d.downloads, 0);
  const copies = project.dailyStats.reduce((a, d) => a + d.copies, 0);

  const session = await getServerSession(authOptions);
  let likedByMe = false;
  let savedByMe = false;
  if (session) {
    const [like, save] = await Promise.all([
      prisma.like.findUnique({ where: { userId_projectId: { userId: session.user.id, projectId: project.id } } }),
      prisma.save.findUnique({ where: { userId_projectId: { userId: session.user.id, projectId: project.id } } })
    ]);
    likedByMe = !!like;
    savedByMe = !!save;
  }

  return NextResponse.json({
    id: project.id,
    title: project.title,
    description: project.description,
    language: project.language,
    code: project.code,
    tags: project.tags,
    featured: project.featured,
    createdAt: project.createdAt,
    author: project.author.username,
    authorId: project.author.id,
    views,
    downloads,
    copies,
    likes: project._count.likes,
    saves: project._count.saves,
    comments: project._count.comments,
    likedByMe,
    savedByMe
  });
}

export async function DELETE(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

  const project = await prisma.project.findUnique({ where: { id: params.id } });
  if (!project) return NextResponse.json({ error: 'غير موجود' }, { status: 404 });

  const me = await prisma.user.findUnique({ where: { id: session.user.id } });
  if (project.authorId !== session.user.id && !me?.isAdmin) {
    return NextResponse.json({ error: 'مش مسموح لك تحذف كود غيرك' }, { status: 403 });
  }

  await prisma.project.delete({ where: { id: params.id } });
  return NextResponse.json({ ok: true });
}
