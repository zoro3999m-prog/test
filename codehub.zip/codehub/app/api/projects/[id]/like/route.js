import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../../lib/auth';
import { prisma } from '../../../../../lib/prisma';
import { dayKey } from '../../../../../lib/format';

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'لازم تسجل الدخول عشان تعجب بكود' }, { status: 401 });

  const projectId = params.id;
  const existing = await prisma.like.findUnique({
    where: { userId_projectId: { userId: session.user.id, projectId } }
  });

  if (existing) {
    await prisma.like.delete({ where: { id: existing.id } });
    const total = await prisma.like.count({ where: { projectId } });
    return NextResponse.json({ liked: false, total });
  }

  await prisma.like.create({ data: { userId: session.user.id, projectId } });
  await prisma.dailyStat.upsert({
    where: { projectId_date: { projectId, date: dayKey() } },
    update: { likes: { increment: 1 } },
    create: { projectId, date: dayKey(), likes: 1 }
  });
  const total = await prisma.like.count({ where: { projectId } });
  return NextResponse.json({ liked: true, total });
}
