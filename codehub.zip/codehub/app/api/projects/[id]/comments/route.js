import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../../lib/auth';
import { prisma } from '../../../../../lib/prisma';

export async function GET(req, { params }) {
  const comments = await prisma.comment.findMany({
    where: { projectId: params.id, hidden: false },
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { username: true } } }
  });
  return NextResponse.json(
    comments.map((c) => ({
      id: c.id,
      text: c.text,
      createdAt: c.createdAt,
      user: c.user.username,
      userId: c.userId
    }))
  );
}

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'لازم تسجل الدخول عشان تعلق' }, { status: 401 });

  const body = await req.json();
  const text = (body.text || '').trim();
  if (!text) return NextResponse.json({ error: 'التعليق فارغ' }, { status: 400 });
  if (text.length > 1000) return NextResponse.json({ error: 'التعليق طويل جدًا' }, { status: 400 });

  const project = await prisma.project.findUnique({ where: { id: params.id } });
  if (!project) return NextResponse.json({ error: 'الكود غير موجود' }, { status: 404 });

  const comment = await prisma.comment.create({
    data: { text, userId: session.user.id, projectId: params.id },
    include: { user: { select: { username: true } } }
  });

  return NextResponse.json({
    id: comment.id,
    text: comment.text,
    createdAt: comment.createdAt,
    user: comment.user.username,
    userId: comment.userId
  });
}
