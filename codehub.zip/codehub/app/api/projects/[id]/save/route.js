import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../../../lib/auth';
import { prisma } from '../../../../../lib/prisma';

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'لازم تسجل الدخول عشان تحفظ كود' }, { status: 401 });

  const projectId = params.id;
  const existing = await prisma.save.findUnique({
    where: { userId_projectId: { userId: session.user.id, projectId } }
  });

  if (existing) {
    await prisma.save.delete({ where: { id: existing.id } });
    return NextResponse.json({ saved: false });
  }

  await prisma.save.create({ data: { userId: session.user.id, projectId } });
  return NextResponse.json({ saved: true });
}
