import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '../../../lib/prisma';

export async function POST(req) {
  const body = await req.json();
  const username = (body.username || '').trim();
  const email = (body.email || '').trim().toLowerCase();
  const password = body.password || '';

  if (!username || !email || !password) {
    return NextResponse.json({ error: 'من فضلك أكمل كل الحقول' }, { status: 400 });
  }
  if (username.length < 3) {
    return NextResponse.json({ error: 'اسم المستخدم قصير جدًا' }, { status: 400 });
  }
  if (password.length < 6) {
    return NextResponse.json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' }, { status: 400 });
  }

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] }
  });
  if (existing) {
    return NextResponse.json({ error: 'اسم المستخدم أو البريد مستخدم بالفعل' }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: { username, email, passwordHash }
  });

  return NextResponse.json({ id: user.id, username: user.username });
}
