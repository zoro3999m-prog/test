import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { dayKey } from '../../../lib/format';

// يستقبل { projectId, type: 'download' | 'copy' } ويزود رقم حقيقي في DailyStat
export async function POST(req) {
  const body = await req.json();
  const { projectId, type } = body;
  if (!projectId || !['download', 'copy'].includes(type)) {
    return NextResponse.json({ error: 'بيانات غير صحيحة' }, { status: 400 });
  }

  const field = type === 'download' ? 'downloads' : 'copies';
  await prisma.dailyStat.upsert({
    where: { projectId_date: { projectId, date: dayKey() } },
    update: { [field]: { increment: 1 } },
    create: { projectId, date: dayKey(), [field]: 1 }
  });

  return NextResponse.json({ ok: true });
}
