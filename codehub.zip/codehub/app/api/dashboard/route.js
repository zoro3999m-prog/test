import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '../../../lib/auth';
import { prisma } from '../../../lib/prisma';
import { dayKey, daysAgoKey } from '../../../lib/format';

const RANGE_DAYS = { '24h': 1, '1w': 7, '1m': 30, '4m': 120, '24m': 730, '1y': 365 };

export async function GET(req) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const range = searchParams.get('range') || '1w';
  const days = RANGE_DAYS[range] || 7;
  const cutoff = daysAgoKey(days - 1);

  const myProjects = await prisma.project.findMany({
    where: { authorId: session.user.id },
    select: { id: true }
  });
  const projectIds = myProjects.map((p) => p.id);

  const statsInRange = projectIds.length
    ? await prisma.dailyStat.findMany({
        where: { projectId: { in: projectIds }, date: { gte: cutoff } }
      })
    : [];

  const totals = statsInRange.reduce(
    (acc, s) => {
      acc.views += s.views;
      acc.likes += s.likes;
      acc.downloads += s.downloads;
      acc.copies += s.copies;
      return acc;
    },
    { views: 0, likes: 0, downloads: 0, copies: 0 }
  );

  // مخطط آخر 7 أيام (عدد المشاهدات كل يوم بدل "دقائق" وهمية غير منطقية لمنصة أكواد)
  const last7Keys = [];
  for (let i = 6; i >= 0; i--) last7Keys.push(daysAgoKey(i).toISOString());

  const statsLast14 = projectIds.length
    ? await prisma.dailyStat.findMany({
        where: { projectId: { in: projectIds }, date: { gte: daysAgoKey(13) } }
      })
    : [];

  const byDate = {};
  statsLast14.forEach((s) => {
    const k = new Date(s.date).toISOString();
    byDate[k] = (byDate[k] || 0) + s.views;
  });

  const barsLast7 = last7Keys.map((k) => byDate[k] || 0);
  const prev7Keys = [];
  for (let i = 13; i >= 7; i--) prev7Keys.push(daysAgoKey(i).toISOString());
  const prevTotal = prev7Keys.reduce((sum, k) => sum + (byDate[k] || 0), 0);
  const total7 = barsLast7.reduce((a, b) => a + b, 0);

  let trend = '— 0%';
  let diffText = 'لا يوجد نشاط بعد';
  const diff = total7 - prevTotal;
  if (prevTotal > 0 && total7 > 0) {
    const pct = Math.round((diff / prevTotal) * 100);
    trend = (diff >= 0 ? '↗ ' : '↘ ') + Math.abs(pct) + '%';
    diffText = Math.abs(diff) + (diff >= 0 ? ' مشاهدة أكثر' : ' مشاهدة أقل');
  } else if (total7 > 0 && prevTotal === 0) {
    trend = '↗ 100%';
    diffText = total7 + ' مشاهدة جديدة';
  }

  const activeDays = barsLast7.filter((v) => v > 0).length;
  const avg = activeDays ? Math.round(total7 / activeDays) : 0;
  const longest = Math.max(...barsLast7, 0);

  const dayLabels = ['أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
  const labels = last7Keys.map((k, i) => {
    if (i === last7Keys.length - 1) return 'اليوم';
    const d = new Date(k);
    return dayLabels[d.getUTCDay()];
  });

  return NextResponse.json({
    published: projectIds.length,
    likes: totals.likes,
    views: totals.views,
    downloads: totals.downloads,
    copies: totals.copies,
    chart: {
      bars: barsLast7,
      labels,
      total: total7,
      avg,
      longest,
      activeDays,
      trend,
      diffText
    }
  });
}
