'use client';

import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function RegisterPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password })
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'حدث خطأ، حاول مرة أخرى');
        setLoading(false);
        return;
      }
      const signInRes = await signIn('credentials', { identifier: email, password, redirect: false });
      setLoading(false);
      if (signInRes?.error) {
        router.push('/login');
        return;
      }
      router.push('/');
      router.refresh();
    } catch {
      setError('حدث خطأ في الاتصال بالسيرفر');
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen main-bg flex items-center justify-center px-4">
      <form onSubmit={onSubmit} className="w-full max-w-sm card">
        <div className="flex items-center gap-3 mb-6 justify-center">
          <div className="logo-mark"><span>{'</>'}</span></div>
          <div className="logo-text">te<span>st</span></div>
        </div>
        <h1 className="text-[20px] font-extrabold text-white mb-1 text-center">إنشاء حساب</h1>
        <p className="text-[12.5px] text-[#8a8aa0] mb-6 text-center">انضم لمجتمع المبرمجين 🚀</p>

        {error && <p className="text-[12.5px] text-[#f87171] bg-[rgba(248,113,113,.1)] border border-[rgba(248,113,113,.25)] rounded-lg px-3 py-2 mb-4">{error}</p>}

        <label className="form-label">اسم المستخدم</label>
        <input className="form-input mb-4" value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} />

        <label className="form-label">البريد الإلكتروني</label>
        <input type="email" className="form-input mb-4" value={email} onChange={(e) => setEmail(e.target.value)} required />

        <label className="form-label">كلمة المرور</label>
        <input type="password" className="form-input mb-6" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />

        <button className="btn-primary w-full justify-center" disabled={loading}>{loading ? 'جارِ الإنشاء...' : 'إنشاء الحساب'}</button>

        <p className="text-[12.5px] text-[#8a8aa0] text-center mt-5">
          عندك حساب بالفعل؟ <Link href="/login" className="text-[#c4b5fd] font-bold">تسجيل الدخول</Link>
        </p>
      </form>
    </div>
  );
}
